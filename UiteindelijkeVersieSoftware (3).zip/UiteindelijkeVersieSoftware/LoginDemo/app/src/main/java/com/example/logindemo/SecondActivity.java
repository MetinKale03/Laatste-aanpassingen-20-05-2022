package com.example.logindemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Date;
import java.util.List;

public class SecondActivity extends AppCompatActivity {
    static final String STATE_CURRENT_FRAGMENT = "currentFragment";
    private WorkViewmodel viewmodel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        viewmodel= ViewModelProviders.of(this).get(WorkViewmodel.class);
        String userName = getIntent().getStringExtra("userName");
        String userPassword= getIntent().getStringExtra("userPassword");
        Double loon=getIntent().getDoubleExtra("loon", 0.0);
        Log.i("LoginDemo:",loon.toString());
        viewmodel.getUserName().setValue(userName);
        viewmodel.getUserPassword().setValue(userPassword);

        BottomNavigationView bottomNav= findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);
        if (savedInstanceState != null) {
            String tag = savedInstanceState.getString(STATE_CURRENT_FRAGMENT);

            Fragment myFragment = (Fragment)getSupportFragmentManager().findFragmentByTag(tag);
            if (myFragment != null ) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,myFragment).commit();
            }
        } else {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment(),"home").commit();
        }

    }
    public Fragment getVisibleFragment(){
        FragmentManager fragmentManager = SecondActivity.this.getSupportFragmentManager();
        List<Fragment> fragments = fragmentManager.getFragments();
        if(fragments != null){
            for(Fragment fragment : fragments){
                if(fragment != null && fragment.isVisible())
                    return fragment;
            }
        }
        return null;
    }

    Date StartDate;
    Date EndDate;
    static final String  STATE_START_DATE= "startDate";
    static final String  STATE_END_DATE= "endDate";
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        Fragment fragment= getVisibleFragment();
        if(fragment !=null){
            Log.i("LoginDemo",fragment.getTag());
            savedInstanceState.putString(STATE_CURRENT_FRAGMENT,fragment.getTag());
        }
        super.onSaveInstanceState(savedInstanceState);
        /*savedInstanceState.putLong(STATE_START_DATE,StartDate.getTime());
        savedInstanceState.putLong(STATE_END_DATE,EndDate.getTime());*/
    }

    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        String tag = savedInstanceState.getString(STATE_CURRENT_FRAGMENT);
        Fragment myFragment = (Fragment)getSupportFragmentManager().findFragmentByTag(tag);
        if (myFragment != null ) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,myFragment).addToBackStack(tag).commit();
        }
        /*StartDate = new Date(savedInstanceState.getLong(STATE_START_DATE));
        EndDate = new Date(savedInstanceState.getLong(STATE_END_DATE));*/

        //getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,selectedFragment).commit();
    }


    private  BottomNavigationView.OnNavigationItemSelectedListener navListener= new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selectedFragment=null;
            String TAG="home";
            Fragment myFragment;
            switch (item.getItemId()){
                    case R.id.nav_home:
                        myFragment = (Fragment)getSupportFragmentManager().findFragmentByTag("home");
                        if (myFragment != null ) {
                            selectedFragment=myFragment;
                        }
                        else
                        {
                            selectedFragment=new HomeFragment();

                        }
                        TAG="home";
                    break;
                    case R.id.nav_work:
                        myFragment = (Fragment)getSupportFragmentManager().findFragmentByTag("work");
                        if (myFragment != null ) {
                            selectedFragment=myFragment;
                        }
                        else
                        {
                            selectedFragment=new WorkFragment();
                        }
                        TAG="work";
                    break;
                    case R.id.nav_info:
                        myFragment = (Fragment)getSupportFragmentManager().findFragmentByTag("info");
                        if (myFragment != null ) {
                            selectedFragment=myFragment;
                        }
                        else{
                            selectedFragment=new InfoFragment();
                        }
                        TAG="info";
                    break;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,selectedFragment,TAG).commit();
            return true;
        }
    };

}